<?php
/**
 *	Plugin Name: Physio Toolkit
 *	Plugin URI: http://www.qreativethemes.com
 *  Description: All plugin territory functionalities for the Physio WordPress Theme, by QreativeThemes
 *	Version: 1.0
 *	Author: QreativeThemes
 *	Author URI: http://www.qreativethemes.com
 *	Text Domain: thelandscaper-toolkit
 *	Domain Path: /languages/
 *
 *	@package physio-toolkit
 *	@author QreativeThemes
 *
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The core plugin class.
 */
if ( ! class_exists( 'PhysioToolkit' ) ) {
	class PhysioToolkit {

		public function __construct() {

			// Get all required files
			$this->physio_toolkit_include_files();
			
			// Load the translation file
			$this->physio_toolkit_load_textdomain();

			// Deactivate QreativeShortcodes plugin if this plugin is activated
			add_action( 'admin_init', array( $this, 'physio_toolkit_on_activation' ) );
		}

		/**
		 * Include all required files
		 */
		private function physio_toolkit_include_files() {

			// Get the custom ACF PRO fields
			require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'includes/acf/acf-fields.php' );

			// Get custom widgets
			require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'includes/widgets/widget-init.php' );

			// Get shortcodes
			require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'includes/shortcodes/shortcodes.php' );
		}

		/**
		 * Load text domain for translation
		 */
		public function physio_toolkit_load_textdomain() {
			load_plugin_textdomain( 'thelandscaper-toolkit', false, trailingslashit( plugin_dir_path( __FILE__ ) ) . 'languages/' ); 
		}

		/**
		 * De-activate the QreativeShortcodes plugin on activation of Physio Toolkit plugin
		 * QreativeShortcodes files moved to this plugin so that plugin is not necessary anymore
		 */
		public function physio_toolkit_on_activation() {

			if ( class_exists( 'QreativeShortcodes' ) ) {
				deactivate_plugins( 'qreativeshortcodes/qreativeshortcodes.php' );
			}
		}
	}
	new PhysioToolkit();
}